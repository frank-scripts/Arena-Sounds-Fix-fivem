fx_version 'cerulean'
game 'gta5'

author 'Frank Williams'
description 'Disable Arena Cheering'
version '1.0.1'

client_script 'client.lua'
