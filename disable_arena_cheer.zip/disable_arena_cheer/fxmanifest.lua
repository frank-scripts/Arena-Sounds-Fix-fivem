fx_version 'cerulean'
game 'gta5'

author 'Frank Williams'
description 'Disable Maze Bank Arena Cheering'
version '1.0'

client_script 'client.lua'
