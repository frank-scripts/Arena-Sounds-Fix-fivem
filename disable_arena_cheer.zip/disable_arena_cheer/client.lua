-- Disable Annoying Sounds Script (Standalone)

-- List of emitters to disable
local emittersToDisable = {
    'se_dlc_aw_arena_crowd_background_main',
    'se_dlc_aw_arena_crowd_exterior_lobby',
    'se_dlc_aw_arena_crowd_interior_lobby',
    'se_dlc_aw_arena_construction_01'
}

-- Disable emitters on client map start
AddEventHandler('onClientMapStart', function()
    -- Wait a moment to ensure all resources are loaded
    Citizen.Wait(1000)

    for _, emitter in ipairs(emittersToDisable) do
        SetStaticEmitterEnabled(emitter, false)
        print(emitter .. " sound disabled.")
    end
end)

-- Monitor player location and disable sounds dynamically
Citizen.CreateThread(function()
    while true do
        local playerCoords = GetEntityCoords(PlayerPedId())

        -- Define areas where sounds should be disabled
        local locationsToDisable = {
            vector3(-225.0, -2027.0, 30.0),  -- Maze Bank Arena
            vector3(3053.1824, -3830.7314, 10.0289)  -- Ocean coordinates where arena cheer is heard
        }

        for _, location in ipairs(locationsToDisable) do
            if #(playerCoords - location) < 500.0 then
                for _, emitter in ipairs(emittersToDisable) do
                    SetStaticEmitterEnabled(emitter, false)
                end
            end
        end

        Citizen.Wait(1000) -- Check every second
    end
end)
