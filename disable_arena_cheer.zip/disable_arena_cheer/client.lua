-- Disable Arena Crowd Cheering Script (Standalone)

-- Register a basic resource initialization event
AddEventHandler('onClientMapStart', function()
    -- Wait a moment to ensure all resources are loaded
    Citizen.Wait(1000)

    -- Disable the cheering sound in Maze Bank Arena
    SetStaticEmitterEnabled('se_dlc_aw_arena_crowd_exterior_lobby', false)

    -- Optional: Notify the player that the emitter is disabled
    print('Maze Bank Arena crowd cheering disabled.')
end)

-- Alternatively, you can use the script to trigger every time the player enters the Maze Bank Arena area
Citizen.CreateThread(function()
    -- Set up the script to check every second
    while true do
        -- Get player coordinates
        local playerCoords = GetEntityCoords(PlayerPedId())

        -- Define the area (Maze Bank Arena) you want to check
        local arenaCoords = vector3(-225.0, -2027.0, 30.0) -- Coordinates of the Maze Bank Arena
        local distance = #(playerCoords - arenaCoords)

        -- Check if player is close to the Maze Bank Arena (within 500 units)
        if distance < 500.0 then
            -- Disable the cheering sound when within the area
            SetStaticEmitterEnabled('se_dlc_aw_arena_crowd_exterior_lobby', false)
        end

        -- Check every second
        Citizen.Wait(1000)
    end
end)
